#include <px4_platform_common/log.h>
#include <px4_platform_common/tasks.h>
#include <px4_platform_common/time.h>
#include <uORB/uORB.h>
#include <uORB/topics/vehicle_attitude.h>
#include <uORB/topics/vehicle_angular_velocity.h>
#include <uORB/topics/manual_control_setpoint.h>
#include <uORB/topics/actuator_outputs.h>
#include <uORB/topics/actuator_armed.h>
#include <math.h>

static constexpr float MAX_THRUST    = 4.5f * 9.81f;
static constexpr float HOVER_THRUST  = 2.5f * 9.81f;
static constexpr float MAX_ALPHA     = 30.0f * M_PI_F / 180.0f;
static constexpr float CT            = 0.008f;
static constexpr float ARM_LENGTH    = 0.18f;
static constexpr float KT            = 1.0f;
static constexpr float KM            = 0.05f;
static constexpr float MAX_ROLL_RATE  = 2.0f;
static constexpr float MAX_PITCH_RATE = 2.0f;
static constexpr float MAX_YAW_RATE   = 1.5f;
static constexpr float MAX_XY_FORCE   = 8.0f;  // 最大水平力 (N)

struct SimplePID {
    float kp, ki, kd;
    float integral;
    float prev_error;
    float dt;
    SimplePID(float p, float i, float d, float time_step) :
        kp(p), ki(i), kd(d), integral(0.0f), prev_error(0.0f), dt(time_step) {}
    float update(float setpoint, float measurement) {
        float error = setpoint - measurement;
        integral += error * dt;
        float derivative = (error - prev_error) / dt;
        prev_error = error;
        return kp * error + ki * integral + kd * derivative;
    }
    void reset() { integral = 0.0f; prev_error = 0.0f; }
};

static bool thread_running = false;

static int omni_control_thread_main(int argc, char *argv[])
{
    int att_sub      = orb_subscribe(ORB_ID(vehicle_attitude));
    int angvel_sub   = orb_subscribe(ORB_ID(vehicle_angular_velocity));
    int man_sub      = orb_subscribe(ORB_ID(manual_control_setpoint));
    int armed_sub    = orb_subscribe(ORB_ID(actuator_armed));

    orb_advert_t act_pub = orb_advertise(ORB_ID(actuator_outputs), nullptr);
    if (act_pub == nullptr) {
        PX4_ERR("actuator_outputs advertise failed");
        thread_running = false;
        return -1;
    }

    const float DT = 0.02f;
    SimplePID pid_roll_rate(0.15f, 0.02f, 0.0f, DT);
    SimplePID pid_pitch_rate(0.15f, 0.02f, 0.0f, DT);
    SimplePID pid_yaw_rate(0.3f, 0.05f, 0.0f, DT);

    while (thread_running) {
        vehicle_attitude_s att;
        vehicle_angular_velocity_s angvel;
        manual_control_setpoint_s man;
        actuator_armed_s armed;

        bool att_ok  = (orb_copy(ORB_ID(vehicle_attitude), att_sub, &att) == 0);
        bool ang_ok  = (orb_copy(ORB_ID(vehicle_angular_velocity), angvel_sub, &angvel) == 0);
        bool man_ok  = (orb_copy(ORB_ID(manual_control_setpoint), man_sub, &man) == 0);
        orb_copy(ORB_ID(actuator_armed), armed_sub, &armed); // 忽略返回值

        if (!att_ok || !ang_ok || !man_ok) {
            px4_usleep(20000);
            continue;
        }

        // 当前姿态
        float q0 = att.q[0], q1 = att.q[1], q2 = att.q[2], q3 = att.q[3];
        float roll  = atan2f(2.0f*(q0*q1 + q2*q3), 1.0f - 2.0f*(q1*q1 + q2*q2));
        float pitch = asinf(2.0f*(q0*q2 - q3*q1));
        float yaw   = atan2f(2.0f*(q0*q3 + q1*q2), 1.0f - 2.0f*(q2*q2 + q3*q3));
        (void)yaw;

        // 当前角速度
        float wx = angvel.xyz[0], wy = angvel.xyz[1], wz = angvel.xyz[2];

        // 遥控器输入
        float stick_roll  = man.roll;
        float stick_pitch = man.pitch;
        float stick_yaw   = man.yaw;
        float stick_thr   = man.throttle;

        // 期望角速度 → 力矩
        float roll_rate_des  = stick_roll  * MAX_ROLL_RATE;
        float pitch_rate_des = stick_pitch * MAX_PITCH_RATE;
        float yaw_rate_des   = stick_yaw   * MAX_YAW_RATE;

        float tau_x_des = pid_roll_rate.update(roll_rate_des, wx);
        float tau_y_des = pid_pitch_rate.update(pitch_rate_des, wy);
        float tau_z_des = pid_yaw_rate.update(yaw_rate_des, wz);

        // 期望推力
        float total_thrust = HOVER_THRUST + stick_thr * (MAX_THRUST * 0.5f);
        if (total_thrust < 0.0f) total_thrust = 0.0f;
        if (total_thrust > MAX_THRUST) total_thrust = MAX_THRUST;
        float Fz_des = total_thrust;

        // 全驱动水平力：摇杆直接映射
        float Fx_des = stick_pitch * MAX_XY_FORCE;
        float Fy_des = stick_roll  * MAX_XY_FORCE;

        // 前馈偏移角 (公式21)
        const float sqrt2 = 1.41421356f;
        float alpha_off[4];
        alpha_off[0] = -sqrt2 * roll + sqrt2 * pitch;
        alpha_off[1] = -sqrt2 * roll - sqrt2 * pitch;
        alpha_off[2] =  sqrt2 * roll - sqrt2 * pitch;
        alpha_off[3] =  sqrt2 * roll + sqrt2 * pitch;

        // 倾转角叠加 (公式27)
        float delta_alpha[4];
        delta_alpha[0] = (-Fx_des - Fy_des) * CT / 4.0f;
        delta_alpha[1] = ( Fx_des - Fy_des) * CT / 4.0f;
        delta_alpha[2] = ( Fx_des + Fy_des) * CT / 4.0f;
        delta_alpha[3] = (-Fx_des + Fy_des) * CT / 4.0f;

        float alpha[4];
        for (int j = 0; j < 4; j++) {
            alpha[j] = alpha_off[j] + delta_alpha[j];
            if (alpha[j] > MAX_ALPHA) alpha[j] = MAX_ALPHA;
            if (alpha[j] < -MAX_ALPHA) alpha[j] = -MAX_ALPHA;
        }

        // 推力分配 (公式26)
        float x_r[4] = { ARM_LENGTH,  ARM_LENGTH, -ARM_LENGTH, -ARM_LENGTH};
        float y_r[4] = {-ARM_LENGTH,  ARM_LENGTH,  ARM_LENGTH, -ARM_LENGTH};
        float sum_abs_y = 4.0f * ARM_LENGTH;
        float sum_abs_x = 4.0f * ARM_LENGTH;

        float thrust_cmd[4];
        for (int j = 0; j < 4; j++) {
            float c = cosf(alpha_off[j]);
            float sign_y = (y_r[j] > 0) ? 1.0f : -1.0f;
            float sign_x = (x_r[j] > 0) ? 1.0f : -1.0f;
            int torque_sign = ((j % 2) == 0) ? 1 : -1;

            thrust_cmd[j] = (1.0f / c) *
                (Fz_des / 4.0f +
                 sign_y * tau_x_des / sum_abs_y +
                 sign_x * tau_y_des / sum_abs_x +
                 torque_sign * (KT * tau_z_des) / (1.0f * KM));
        }

        // 发布 actuator_outputs
        actuator_outputs_s act{};
        act.timestamp = hrt_absolute_time();
        act.noutputs = 16;
        for (int j = 0; j < 4; j++) {
            float motor_val = thrust_cmd[j] / MAX_THRUST;
            if (motor_val > 1.0f) motor_val = 1.0f;
            if (motor_val < 0.0f) motor_val = 0.0f;
            act.output[j] = motor_val;

            float servo_val = alpha[j] / MAX_ALPHA;
            if (servo_val > 1.0f) servo_val = 1.0f;
            if (servo_val < -1.0f) servo_val = -1.0f;
            act.output[4 + j] = servo_val;
        }
        for (int k = 8; k < 16; k++) act.output[k] = 0.0f;

        if (armed.armed) {
            orb_publish(ORB_ID(actuator_outputs), act_pub, &act);
        } else {
            actuator_outputs_s act_zero{};
            act_zero.timestamp = hrt_absolute_time();
            act_zero.noutputs = 16;
            orb_publish(ORB_ID(actuator_outputs), act_pub, &act_zero);
        }

        static int print_cnt = 0;
        print_cnt++;
        if (print_cnt % 10 == 0) {  // 每 10 个周期 (200ms) 打印一次
            PX4_INFO("stick:%.2f %.2f %.2f %.2f | F:%.1f %.1f %.1f | tau:%.2f %.2f %.2f | a:%.2f %.2f",
                     (double)stick_roll, (double)stick_pitch, (double)stick_yaw, (double)stick_thr,
                     (double)Fx_des, (double)Fy_des, (double)Fz_des,
                     (double)tau_x_des, (double)tau_y_des, (double)tau_z_des,
                     (double)alpha[0], (double)alpha[1]);
        }

        px4_usleep(20000);
    }

    orb_unsubscribe(att_sub);
    orb_unsubscribe(angvel_sub);
    orb_unsubscribe(man_sub);
    orb_unsubscribe(armed_sub);
    return 0;
}

extern "C" __EXPORT int omni_control_main(int argc, char *argv[])
{
    if (thread_running) {
        PX4_INFO("Already running");
        return 0;
    }
    thread_running = true;
    px4_task_spawn_cmd("omni_control",
                       SCHED_DEFAULT,
                       SCHED_PRIORITY_MAX - 20,
                       4000,
                       omni_control_thread_main,
                       nullptr);
    PX4_INFO("Omni Control (full-actuation) started");
    return 0;
}
