#include <px4_platform_common/module.h>
#include <px4_platform_common/log.h>
#include <unistd.h>

extern "C" __EXPORT int swarm_bridge_main(int argc, char *argv[]);

int swarm_bridge_main(int argc, char *argv[])
{
    PX4_INFO("Swarm Bridge module started");
    while (true) {
        usleep(100000);
    }
    return 0;
}
